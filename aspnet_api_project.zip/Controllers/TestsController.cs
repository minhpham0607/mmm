using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[Authorize]
[Route("api/tests")]
[ApiController]
public class TestsController : ControllerBase
{
    private readonly ITestService _testService;

    public TestsController(ITestService testService)
    {
        _testService = testService;
    }

    [HttpGet]
    public IActionResult GetAllTests() => Ok(_testService.GetAllTests());

    [HttpPost]
    public IActionResult CreateTest([FromBody] Test test)
    {
        var createdTest = _testService.CreateTest(test);
        return CreatedAtAction(nameof(GetAllTests), new { id = createdTest.Id }, createdTest);
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteTest(int id)
    {
        var deleted = _testService.DeleteTest(id);
        if (!deleted) return NotFound();
        return NoContent();
    }
}