public class Test
{
    public int Id { get; set; }
    public string Tieude { get; set; }
    public int SoCau { get; set; }
    public string DapGiaoCho { get; set; }
    public DateTime NgayTao { get; set; }
    public DateTime NgayThi { get; set; }
}